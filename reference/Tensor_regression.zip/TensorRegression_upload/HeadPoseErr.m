function [pvec_err,pan_err,tilt_err,roll_err]=HeadPoseErr(EHP_GT,EHP_EST)
% 
% compute absolute pointing vector, pan, tilt, and roll head pose tracking
% [pvec_err,pan_err,tilt_err,roll_err]=HeadPosetrackingErr(session,RecLabel,side,DatabasePath,EHP_EST,VFrameMin,VFrameMax);
%
% input:
% session: 'meetin' for meeting recording and 'office' for office
% recordings
% RecLabel: recording label. in {1,...,8} for meetings and {1,...,16} for
% office recordings
% side: side of the person in meeting 'R' for right and 'L' for left. 'C'
% for office recording
% DatabasePath: head pose database path
% EHP_EST      : head pose tracking output
% VFrameMin    : first video frame
% VFrameMax    : last video frame
%
% outputs:
% pvec_err  : pose tracking error  ( pvec_err(1)=mean, pvec_err(2)=std, pvec_err(2)=median )
% pan_err   : pan tracking error   ( pan_err(1)=mean, pan_err(2)=std, pan_err(2)=median )
% tilt_err  : tilt tracking errors ( tilt_err(1)=mean, tilt_err(2)=std, tilt_err(2)=median )
% roll_err  : roll tracking errors ( roll_err(1)=mean, roll_err(2)=std, roll_err(2)=median )



pan_err_t=abs(AngDist(EHP_GT(:,1),EHP_EST(:,1)));
tilt_err_t=abs(AngDist(EHP_GT(:,2),EHP_EST(:,2)));
roll_err_t=abs(AngDist(EHP_GT(:,3),EHP_EST(:,3)));

NData=size(EHP_EST,1);
pose_err_t=zeros(1,NData);
for t=1:NData
    pose_err_t(t)=(180/pi)*acos(sum(PoseVector(EHP_EST(t,:)).*PoseVector(EHP_GT(t,:))));
end

pvec_err=ComputeErr(pose_err_t);
pan_err=ComputeErr(pan_err_t);
tilt_err=ComputeErr(tilt_err_t);
roll_err=ComputeErr(roll_err_t);


function v=PoseVector(pose)
pose=(pi/180)*pose;
v=[sin(pose(1)),-sin(pose(2))*cos(pose(1)),cos(pose(2))*cos(pose(1))];

function err=ComputeErr(err_t)
err(1)=mean(err_t);
err(2)=std(err_t);
err(3)=median(err_t);



