function [U, d, err, err_iter] = genTensorRegression_head(InputData, InputTarget, varargin)
% tensor ridge regression
% Input:
%      InputDate : the Data Tensor, I1xI2x...xI_MxN, N is the number of
%                  training data, and M is the modes of a single tensor
%                  observation
%      InputTarget : the output variable : Nx1
%      varargin :
%               vargargin{1} : the regularization paramters, lambda
%               varargin{2}  : the rank
% Output
%      U : the factor matrices of regression weights
%      d : the bias
%      err : the trainign error
% Dependencies : tensor toolbox
%
% Written by Weiwei Guo
if nargin > 2
    lambda = varargin{1}; % regularization parameter
    R = varargin{2}; % rank
else
    R = 18; % number of components
    lambda = 0.1;
end

epsilon = 1e-6; % the tolerance for convergence 
maxIter = 30; % the maximum number of  iteration 


Dims = size(InputData);
N = Dims(end); % the number of training data
ndim = length(Dims) - 1;



U = cell(1, ndim);
cumDims = [0 cumsum(Dims(1:ndim))];
if nargin > 4
    W = varargin{3};
    W = reshape(W(1:end), Dims(1:end-1));
    W = tensor(W);
    W = cp_als(W, R);  
    U0 = zeros(sum(Dims(1:ndim))*R, 1);
    for i = 1 : ndim
        UU{i} = W.U{i}*((diag(W.lambda)).^(1/ndim));
        U0(cumDims(i)*R+1 : cumDims(i+1)*R) = reshape(UU{i}, Dims(i)*R, 1);
    end
    U = UU;    
else
    % Initialization
    % randomized
    for i = 1 : ndim
        u = rand(Dims(i), R);
        u = -1 + 2*u;
        U{i} = u;
    end
end

% Iteration
debug = 0;
Loop = 1;

iter = 0;
err_iter = [];
pred = zeros(N,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
while(Loop)
    iter = iter + 1;
    Uold = U;
    for i = 1 : ndim
        Phi = zeros(N, prod(size(U{i}))+1);
        for n = 1 : N
            Xdata = InputData(:,:, n);
            xi = mttkrp(Xdata, U, i);
            Phi(n,:) = [(xi(:))' 1];
        end
        %-----------------------------------------------------------------------%%
        %
        %           ridge regression
        [ignorce dim] = size(Phi);
%         Ui = khatrirao(U{[1:i-1 i+1:ndim]}, 'r') ;
%         ui = trace(Ui*Ui');
%         ww = inv(lambda(nL)*ui*eye(dim)+Phi'*Phi)*Phi'*InputTarget;
        ww = pinv(lambda*eye(dim)+Phi'*Phi)*Phi'*InputTarget;
        U{i} = reshape(ww(1:end-1), Dims(i), R);
        d = ww(end);
        
        %------------------------------------------------------------------
        % debug
        if debug==1
            pred = zeros(N,1);
            for n = 1 : N
                ten_U = ktensor(U);
                ten_U = tensor(ten_U);
                Xdata = InputData(:,:,n);
                pred(n) = innerprod(Xdata, ten_U);
            end
            err = InputTarget - pred;
            d = mean(err);
            err_iter = [err_iter ; sqrt(mean((err-d).^2))];
        end
        %-----------------------------------------------------------------------
        
        
        ten_U_old = ktensor(Uold);
        ten_U = ktensor(U);
        
        norm_u = norm(ten_U);
        norm_u_gap = norm(ten_U - ten_U_old);
        tor = norm_u_gap/norm_u;
        % check terminatation conditions
        fprintf('Iteration: %d, Tor: %f\n', iter, tor);
        if(iter > maxIter)
            Loop = 0;
        end
        if(tor < epsilon)
            Loop = 0;
        end
    end
end    

for n = 1 : N
    ten_U = ktensor(U);
    ten_U = tensor(ten_U);
    Xdata = InputData(:,:,n);
    
    pred(n) = innerprod(Xdata, ten_U)+d;   
end

err = InputTarget - pred;
err = sqrt(mean((err).^2));


