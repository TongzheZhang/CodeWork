function [U, d, err, err_iter] = linTensorSVR_head(InputData, InputTarget, varargin)
% linear support vectors regression in tensor regrensation


Dims = size(InputData);
N = Dims(end); % the number of training data
ndim = length(Dims) - 1;

epsilon = 1e-4;

if nargin < 3
    R = 6;
else
    R = varargin{1};
    c = varargin{2};
end
% initialization
U = cell(1, ndim);
if nargin < 5
    for i = 1 : ndim
        u = rand(Dims(i), R);
        u = -1 + 2*u;
        U{i} = u;
    end
else
    W = varargin{3};
    W = reshape(W(1:end), Dims(1:end-1));
    W = tensor(W);
    W = cp_als(W, R);
    % cumDims = [0 cumsum(Dims(1:ndim))];
    % U0 = zeros(sum(Dims(1:ndim))*R,1);
    for i = 1 : ndim
        U{i} = W.U{i}*((diag(W.lambda)).^(1/ndim));
    end
end



% Iterations
Loop = 1;
maxIter =30;
iter = 0;
err_iter = [];
debug = 0;

libsvm_options = sprintf('-s %d -t %d  -c %f', 3, 0, c);



while(Loop)
    iter = iter + 1;
    Uold = U;
    
    for i = 1 : ndim
        
        Phi = zeros(N, prod(size(U{i})));
        
        % project the data
        % computing matrix B
        B = ones(R, R);
        for j = [1:i-1 i+1:ndim]
            B = B.*((U{j})'*U{j});
        end
        % sqrt B and inverse sqrt B
        [sqrtB resnorm] = sqrtm(B);
        invsqrtB = inv(sqrtB);
        for n = 1 : N
            Xdata = InputData(:,:,n);
            xi = mttkrp(Xdata, U, i);
            xi = xi*invsqrtB;
            Phi(n,:) = (xi(:))';            
        end
        
        % support vector regression
        [ignorce dim] = size(Phi);
        ww = zeros(dim,1);
        model = svmtrain(InputTarget,Phi,libsvm_options);
        
        % compute the weights
        ww = model.SVs'*model.sv_coef;
        d = -model.rho;
     
        ww_tmp = reshape(ww, Dims(i), R); 
        ww_tmp = ww_tmp*invsqrtB;
        U{i} = ww_tmp;     
    end
    
    
    if debug==1
        pred = zeros(N,1);
        for n = 1 : N
            ten_U = ktensor(U);
            ten_U = tensor(ten_U);
           
            Xdata = InputData(:,:,n);

            
            pred(n) = innerprod(Xdata, ten_U);
        end
        err = InputTarget - pred;
        d = mean(err);
        err_iter = [err_iter ;sqrt(mean((err-d).^2))];
    end

    ten_U_old = ktensor(Uold);
    ten_U = ktensor(U);
    
    norm_u = norm(ten_U);
    norm_u_gap = norm(ten_U - ten_U_old);
    tor = norm_u_gap/norm_u;
    
    % check the termination conditions
    fprintf('Iteration:%d, Tor:%f\n', iter, tor);
    if(iter > maxIter)
        Loop = 0;
    end
    if(tor < epsilon)
        Loop = 0;
    end
end

% computing d
pred = zeros(N, 1);
for n = 1 : N
    ten_U = ktensor(U);
    ten_U = tensor(ten_U);    
    Xdata = InputData(:,:,n);     
    pred(n) = innerprod(Xdata, ten_U);
end
err = InputTarget - pred;
% d = mean(err);
err = sqrt(mean((err-d).^2));