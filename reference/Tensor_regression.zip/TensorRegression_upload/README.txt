%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Authors: Weiwei Guo, Irene Kotsia, Ioannis Patras                  %                                         
% Email : thinkheaven@gmail.com                                      %
% Affiliation: School of Electrical Engineering and Computer Science %
%              Queen Mary, University of London                      %
% Date: 12/10/2011                                                   %
%                                                                    % 
% Copyright (c) 2011  Weiwei Guo - All rights reserved               %
%                                                                    %
% This software is free for non-commercial usage only. It must       %
% not be distributed without prior permission of the author.         %
% The author is not responsible for implications from the            %
% use of this software. You can run it at your own risk.             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

This is sample implementation of Tensor Learning for Regression. Please cite as  

    Weiwei Guo, Irene Kotsia, Ioannis Patras, "Tensor Learning for Regression", 
	IEEE Trans. on Image Processing, pp. 816-827, Feb. 2012

    http://www.eecs.qmul.ac.uk/~ioannisp/pubs/ecopies/kotsia_tip_2011.pdf
    Bibtex reference: http://www.eecs.qmul.ac.uk/~ioannisp/pubs/ecopies/kotsia_tip_2011_bib.bib

%[Dependencies]%
  Tensor Toolbox : 
    This function needs the tensor toolbox available at http://csmr.ca.sandia.gov/~tgkolda/TensorToolbox/ 
  SVM solver:
    Libsvm toolbox 

%[Table of Contents]%
demo_headpose.m       : demonstrate the algorithms on a head pose dataset and show the usages
genTensorRegression.m : training high order rigde regression 
linTensorSVR.m        : train higher order support tensor regression
orTensorRegression.m  : train optimal rank tensor regression model
HeadPoseErr.m         : calculate the head pose estimation error.

%[Dataset]%
You can download that BU Head Pose dataset from http://csr.bu.edu/headtracking/uniform-light/ and
other datasets are also possible, like age estimation
     

%[Comment/Question?]%
Please send your comment (e.g., ways to improve the codes) or question (e.g., 
difficulty in using the codes) to thinkheaven@gmail.com
