%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: WEIWEI GUO                                                 %   
% E-Mail: thinkheaven@gmail.com                                      %
% Date: 05/05/2011                                                   %
%                                                                    %
% This function needs the tensor toolbox available at                %
% http://csmr.ca.sandia.gov/~tgkolda/TensorToolbox/                  %
%                                                                    %
% Please email me if you have any problem, question or suggestion    %
%                                                                    %
% Copyright (c) 2011  Weiwei Guo - All rights reserved               %
%                                                                    %
% This software is free for non-commercial usage only. It must       %
% not be distributed without prior permission of the author.         %
% The author is not responsible for implications from the            %
% use of this software. You can run it at your own risk.             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% demo head pose estimation by regression with tensor representation
clear all
close all


% Add Path
% addpath('.\utils\liblinear-1.7\matlab')
addpath('.\utils\libsvm-mat-2.9-1')
% addpath('.\utils\poblano_toolbox_1.0')

%% Load Database

%load('.\data\UvA_HeadPose\DB_UAV_HeadPose.mat');

%% Split the data
% S = database(:,1);
% V = database(:,2);
% L = (S == 1 & V == 1) | (S == 1 & V == 2) | (S == 1 & V == 3)| (S == 2 & V == 7) |(S == 2 & V == 8) | (S == 2 & V == 9) | (S == 5 & V == 4 ) |(S == 5 & V == 5) | (S == 5 & V == 6)|(S == 4 & V == 2) | (S == 4 & V == 8); 
% 
% Xtrain = database(L, 3:1202)/255;
% Ytrain = database(L, 1203: 1205);
% Xtest = database(~L, 3:1202)/255;
% Ytest = database(~L, 1203: 1205);

clear database

%% Reshape with mult-way array
TrainData = reshape(Xtrain', 40, 30, size(Xtrain,1));
TestData = reshape(Xtest', 40, 30, size(Xtest,1));

TrainData = tensor(TrainData);
TestData =  tensor(TestData);

%% Training
models = [];
model = [];
R = 3;
lambda = 1000;
C = 0.005;
libsvm_options = sprintf('-s %d -t %d -c %f', 3, 0, C);
tic;
for l = 1 :  size(Ytest, 2)
    fprintf('<------------ Training for model : %d/%d----------------->\n', l, size(Ytest, 2));
    [U, d, train_err] = genTensorRegression(TrainData, Ytrain(:, l), lambda, R); % tensor ridge regression
%     [U, d, train_err] = linTensorSVR(TrainData, Ytrain(:,l), C, R);     % tensor svr
%    [U d Alpha beta train_err] = orTensorRegression(TrainData, Ytrain(:,l), 18, 'lsq', 'grl', 0.1, libsvm_options);
    model.U = U;
    model.b = d;
    model.train_err = train_err;
    models = [models model];
end
t = toc;
%% testing
YPt = zeros(size(Ytest));
fprintf('Total : %d/%04d', size(Ytest, 1), 0);
for i = 1 : 1:   size(Ytest, 1)
    Xdata = TestData(:,:,i);
    fprintf('\b\b\b\b%04d' ,i);
    for l = 1 : size(Ytest, 2)
        model = models(l);
        U = model.U;
        d = model.b;
        ten_U = ktensor(U);
        ten_U = tensor(ten_U);
        YPt(i, l) = innerprod(Xdata, ten_U)+d;
    end
end
[pvec_err_trr,pan_err_trr,tilt_err_trr,roll_err_trr]= HeadPoseErr(Ytest , YPt);
fprintf('\n');

