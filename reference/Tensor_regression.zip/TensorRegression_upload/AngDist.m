function d=AngDist(ang1,ang2)
% compute distance betwen angle
d=zeros(length(ang1),1);
for l=1:length(ang1)
    d(l)=min([abs(ang1(l)-ang2(l)) abs(ang1(l)-ang2(l)-360) abs(ang1(l)-ang2(l)+360)]);
end