[y,xt] = libsvmread('../heart_scale');
model= train(y, sparse(xt))
[l,a]=predict(y, xt, model);

