%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                       Support Tucker Machines                               %
%                                                                             %
% Written by Irene Kotsia                                                     %
% contact email: irene.kotsia@eecs.qmul.ac.uk                                 %
% Release date:   11 October, 2011                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

The functions provided are the implementations of the two Support Tucker Machines variations
(STuMs and Sw-STuMs) presented in :

I. Kotsia and I. Patras, "Support Tucker Machines" , International Conference on
 Computer Vision and Pattern Recognition, Jun. 2011, Colorado, USA. 

The package includes 3 .m files:

 
stums_train.m     -  the training function for Support Tucker Machines
stums_sw_train.m  -  the training function for Sw-Support Tucker Machines 
stums_test.m      -  the testing function for the 2 variations of Support Tucker Machines

Dependancies:
The code uses the spider matlab package (for the SVMs algorithms) as well as the tensor toolbox provided by Sandia National Laboratories
(http://csmr.ca.sandia.gov/~tgkolda/TensorToolbox/) (for the tensor implementations). 

General comments:
Try playing with the number of iterations, value of epsilon (stopping threshold) and the C parameter in SVMs (found in the spider folder under /pat/@svm/svm.m).
In general you have to experiment with all of the above to achieve the best results.

Please refer to the comments in the .m files for explanations.


In all documents and papers reporting research work that uses the matlab codes 
provided here, the respective author(s) must reference the following paper: 

[1]	I. Kotsia and I. Patras, "Support Tucker Machines" , International Conference on
 Computer Vision and Pattern Recognition, Jun. 2011, Colorado, USA. 



Please send your comments or questions to irene.kotsia@eecs.qmul.ac.uk


 
