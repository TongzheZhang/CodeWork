%    SUPPORT TUCKER MACHINES - Demo
%
%    Copyright by Irene Kotsia
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
epsilon =0.1;%threshold criterion, play with it to achieve better results

number_of_iterations = 3;%number of iterations, play with it to achieve better results

Rank=3; %rank, play with it to achieve better results.Should be greater or equal to 2

%here we create a toy example with tensors of dimensrion 3x4x5, each class
%consisting of 100 examples
train_data_class1=tensor(1*randn(3,4,5,100));
train_data_class2=tensor(2*randn(3,4,5,100)+5);
train_data=train_data_class1;
train_data(:,:,:,101:200)=train_data_class2;
train_labels=ones(200,1);
train_labels(101:end)=-1;

test_data_class1=tensor(0.900*randn(3,4,5,100));
test_data_class2=tensor(1.900*randn(3,4,5,100)+4.5);
test_data=test_data_class1;
test_data(:,:,:,101:200)=test_data_class2;
test_labels=ones(200,1);
test_labels(101:end)=-1;

[U,G,b]=stums_train(train_data,train_labels',Rank,number_of_iterations,epsilon);  % for STuMs
%[U,G,b]=stums_sw_train(train_data,train_labels',Rank,number_of_iterations,epsilon); %for Sw-STuMs


[predictions]=stums_test(test_data,test_labels',U,G,b); %testing function

fprintf('Classification accuracy equal to');
100*length(find(predictions==test_labels))/length(test_labels)