%    SUPPORT TUCKER MACHINES - TRAINING
%    INPUTS:
%               train_data            :   the set of training data being in the
%                                         format l x m x k x n where l, m and k are the dimensions of
%                                         the tensor and n are the example available
%               train_labels          :   the training labels for the n available examples
%               Rank                  :   the desirable tensor rank
%               number_of_iterations  :   the maximum number of iterations
%                                         allowed. Typical value equal to
%                                         30
%               epilon                :   stopping threshold. Typical value
%                                         10^{-1:-5}
%    OUTPUTS:
%               U            :   the weights tensor
%               G            :   the core tensor G
%               b            :   the parameter b of STMs
%   Change line 78:  Xdata = train_data(:,:,:,n); according to the
%   dimensionality of your data
%
%    Copyright by Irene Kotsia
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [U,G,b]=stums_train(train_data,train_labels,Rank,number_of_iterations,epsilon);

G=tensor(rand(Rank,Rank,Rank));                                             %the core tenor G is of dimension Rank x Rank x Rank

Dims = size(train_data);                                                    %find the dimension of the tensor
N = Dims(end);                                                              %find the number of examples
number_of_modes = length(Dims) - 1;                                         %find the number of modes

Loop = 1;
iter = 0;

U = cell(1, number_of_modes);                                               %create the random U rank one tensors
cumDims = [0 cumsum(Dims(1:number_of_modes))];

for i = 1 : number_of_modes
    u = rand(Dims(i), Rank);
    u = -1 + 2*u;
    U{i} = u;
end


while(Loop)

    iter = iter + 1;


    modes=1:number_of_modes;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %           Start calculation of weights tensors U for each mode
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    for mode=1:number_of_modes
        U_old=U;
        Gold=G;

        Phi = zeros(N, prod(size(U{mode})));
        ten_U_old = ktensor(U_old);

        ten_U = ktensor(U);

        B =  setdiff(modes,mode) ;                                          %calculate the matrix B

        if (Rank==1)
            P=double(tenmat( ttv(G,{U_old{B(1)},U_old{B(2)}},B), mode));    %inner product of tensors G and U
        end
        if(Rank~=1)

            P = double( tenmat( ttm(G,{U_old{B(1)},U_old{B(2)}},B), mode));
        end
        K   = P*P';


        [sqrtB resnorm] = sqrtm(K);
        invsqrtB = inv(real(sqrtB));                                        % sqrt B and inverse sqrt B
        A =P'*invsqrtB;

        for n = 1 : N

            Xdata = train_data(:,:,:,n);
            xi = double(tenmat(Xdata,mode));
            xi = xi*A;
            xi_final=reshape(xi,[size(xi,1)*Rank 1]);
            Phi(n,:) =  xi_final';
        end


        [ignorce dim] = size(Phi);
        ww = zeros(dim,1);
        d=data(Phi);
        d.Y=train_labels';

        if(mode==1)
            [r,net]=train(svm({kernel('linear'),'optimizer="andre"'}),d);   %train the 1st mode SVM
            net_old=net;

        end
        if(mode~=1)                                                         %train the other modes' SVMs 
            [r,net]=train(net_old,d);                                       %They should take under consideration the SVMs
            net_old=net;                                                    %of the other modes
        end
       
       
        wout=get_w(net);                                                    %get the weight calculated by the SVM

        wout=wout';
        ww_tmp = reshape(wout, [size(train_data,mode)  Rank]);              %reshape the weight to have the dimension specified by the Rank
       
        wout = ww_tmp*invsqrtB;

        U{mode} = wout;

        clear Phi;
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %           Start calculation of core tensor G
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    for n = 1 : N                                                           %repeat the procedure presented above to get the core tensor G
                                                                            %using the acquired weights tensor U
        Xdata = train_data(:,:,:,n);
        x_1=ttm(Xdata,{U{1}',U{2}',U{3}'}) ;
        x_1= tenmat( x_1,1);
        xi_final=reshape(double(x_1),[size(x_1,1)*size(x_1,2) 1]);
        Phi(n,:) = xi_final';
    end

    [ignorce dim] = size(Phi);
    ww = zeros(dim,1);
    dg=data(Phi);
    dg.Y=train_labels';


     
    [r,netg]=train(net,dg);                                                %train the SVM to get it's weight to create core tensor G
    
    wgout=get_w(netg);
    
    wgout=wgout';
    b=netg.b0;                                                             %keep the b parameter of the last SVMs used
    
    ww_tmp = reshape(wgout, [Rank Rank Rank]);                             %reshape the weight to the dimensions of the core tensor G

    G_new = tensor(ww_tmp);                                                %create the core tensor G


    ten_U_old = ttensor(tensor(G),U_old);
    tenUold=full(ten_U_old);
    ten_U = ttensor(tensor(G_new),U);
    tenU=full(ten_U);
    norm_u = norm(ten_U);
    norm_u_gap = norm(tenU - tenUold);
    tor = norm_u_gap/norm_u;
    G=G_new;
    
    
     fprintf('Iteration number:%d,   Threshold is :%f\n', iter, tor);       % check the stopping conditions
    if(iter > number_of_iterations)                                        %either you have exceeded the maximum number of iterations
        Loop = 0;
    end
    if(tor < epsilon)                                                      %or you have exceeded the threshold
        Loop = 0;
    end
    clear net;



end

