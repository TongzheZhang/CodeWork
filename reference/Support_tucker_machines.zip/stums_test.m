%    SUPPORT TUCKER MACHINES  - TESTING
%    INPUTS:
%               test_data             :   the set of testing data being in the
%                                         format l x m x k x n where l, m and k are the dimensions of
%                                         the tensor and n are the example available
%               test_labels           :   the testing labels for the n available examples
%               U                     :   the weights tensor of the trained STM
%               G                     :   the core tensor G
%               b                     :   the parameter b of STMs
%
%    OUTPUTS:
%               predictions           :   the predicted labels
%
%   Change line 30:  Xdata = test_data(:,:,:,n); according to the
%   dimensionality of your data
%
%    Copyright by Irene Kotsia
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [predictions]=stms_test(test_data,test_labels,U,G,b);

Dims = size(test_data);                                                    %find the dimension of the tensor
N = Dims(end);                                                             %find the number of examples
number_of_modes = length(Dims) - 1;                                        %find the number of modes

predictions=[];

pred = zeros(N, 1);

ten_U = ttensor(tensor(G),U);
tenU=full(ten_U);

for n = 1 : N
    Xdata = test_data(:,:,:,n);
    pred(n) = innerprod(Xdata, ten_U);                                     %calculate the inner product of the test tensor with the weight tensor
end
w_test=pred+b;                                                             %add the b of the trained STMs

predictions=[predictions w_test];                                          %store the predicted labels

pos=find(predictions>0);                                                   %find the positive labels
neg=find(predictions<0);                                                   %find the negative labels
predictions(pos)=1;
predictions(neg)=-1;
