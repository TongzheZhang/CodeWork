%    Sw-SUPPORT TENSOR MACHINES WITH THE WEIGHTS EXPRESSED AS A TENSOR - TRAINING
%    INPUTS:
%               train_data            :   the set of training data being in the
%               format l x m x k x n where l, m and k are the dimensions of
%               the tensor and n are the example available
%               train_labels          :   the training labels for the n available examples
%               Rank                  :   the desirable tensor rank
%               number_of_iterations  :   the maximum number of iterations
%                                         allowed. Typical value equal to
%                                         30
%               epilon                :   stopping threshold. Typical value
%                                         10^{-1:-5}
%    OUTPUTS:
%               U            :   the weights tensor
%               b            :   the parameter b of STMs
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [U,b]=stms_sw_train(train_data,train_labels,Rank,number_of_iterations,epsilon);

Dims = size(train_data);                                                    %find the dimension of the tensor
N = Dims(end);                                                              %find the number of examples
number_of_modes = length(Dims) - 1;                                         %find the number of modes


Loop = 1;
iter = 0;

U = cell(1, number_of_modes);                                               %create the random U rank one tensors
cumDims = [0 cumsum(Dims(1:number_of_modes))];

for i = 1 : number_of_modes
    u = rand(Dims(i), Rank);
    u = -1 + 2*u;
    U{i} = u;
end


while(Loop)

    iter = iter + 1;

    Uold=U;

    modes=1:number_of_modes;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %           Start calculation of weights tensors U for each mode
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    for mode=1:number_of_modes

        Phi = zeros(N, prod(size(U{mode})));

                                                                            % project the data
                                                                            % computing matrix B
        B = ones(Rank, Rank);
        for j = [ setdiff(modes,mode)]
            B = B.*((U{j})'*U{j});                                          %    B=(U^{(-j)})^T U^{(-j)} 
        end
        
        [sqrtB resnorm] = sqrtm(B);                                         % sqrt B and inverse sqrt B
        invsqrtB = inv(sqrtB);

        for n = 1 : N
            Xdata = train_data(:,:,:,n);
            xi = mttkrp(Xdata, U, mode);
            xi = xi*invsqrtB;
            Phi(n,:) = (xi(:))';
        end

        [ignorce dim] = size(Phi);
        ww = zeros(dim,1);

        d.Y=train_labels';

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %           Calculate the covariance matrix Sw for each mode
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        yes_train=find(train_labels==1);                                   %find positive training examples
        no_train=find(train_labels==-1);                                   %find negative training examples

        all_data=Phi';

        
        all_data_yes=all_data(:,yes_train);                                %normalize data by subtracting their mean value
        all_data_no=all_data(:,no_train);

        all_data_yes_mean=mean(all_data_yes,2);
        all_data_yes=all_data_yes-repmat(all_data_yes_mean,1,size(all_data_yes,2));
        all_data_no_mean=mean(all_data_no,2);
        all_data_no=all_data_no-repmat(all_data_no_mean,1,size(all_data_no,2));

        all_data=[all_data_no all_data_yes];

        Nc=[length(no_train) length(yes_train)];


        
        Training=all_data; 
        sampleMean                              = mean(Training,2);
        [m n]                                   = size(Training);
        Sw                                     = zeros(m,m);
        Sb                                      = zeros(m,m);

        Sw = cov(all_data(:,no_train)') + cov(all_data(:,yes_train)');
               
%         [eVec  , eval  ]=eig(Sw);
%         eval=diag(eval);
%         eval_pos=find(eval>0);
%         eval_neg=find(eval<0);
%         eVec_pos=eVec(:,eval_pos);
%         eVec_neg=eVec(:,eval_neg);
%            p      = length(eval_pos);   %positive euclidean space dimensionality
% 
%         q      = length(eval_neg);
%         X_sign = [eVec_pos eVec_neg]*abs([diag(eval_pos) zeros(p,q); zeros(q,p) diag(eval_neg)])^(-1/2);
        
        clear Training;
        clear all_data;
         
        myX= (Sw+0.1*eye(size(Sw)))^(-1/2)*Phi';                            %multiply Sw with the training data

        

        d=data(myX');
        d.Y=train_labels';

        if(mode==1)                                                         %train the 1st mode SVM
            [r,net]=train(svm({kernel('linear'),'optimizer="andre"'}),d);
            net_old=net;
            
        end
        if(mode~=1)                                                         %train the other modes' SVMs 
            [r,net]=train(net_old,d);                                       %They should take under consideration the SVMs
            net_old=net;                                                    %of the other modes
        end
      
        wout=get_w(net);                                                    %get the weight calculated by the SVM
        wout=wout';
        
       
        ww_tmp = reshape(wout, Dims(mode), Rank);                           %reshape the weight to have the dimension specified by the Rank
        wout = ww_tmp*invsqrtB;

         
        U{mode} = wout;                                                     %create the weights tensor
        b=net.b0;                                                           %keep the b parameter of the last SVMs used
    end



    ten_U_old = ktensor(Uold);

    ten_U = ktensor(U);

    norm_u = norm(ten_U);
    norm_u_gap = norm(ten_U - ten_U_old);
    tor = norm_u_gap/norm_u;

    fprintf('Iteration number:%d,   Threshold is :%f\n', iter, tor);       % check the stopping conditions
    if(iter > number_of_iterations)                                        %either you have exceeded the maximum number of iterations
        Loop = 0;
    end
    if(tor < epsilon)                                                      %or you have exceeded the threshold
        Loop = 0;
    end
    clear net;



end

