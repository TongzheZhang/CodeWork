% This make.m is for MATLAB and OCTAVE under Windows, Mac, and Unix

try
	Type = ver;
	% This part is for OCTAVE
	if(strcmp(Type(1).Name, 'Octave') == 1)
		mex -DPOLY2 libsvmread.c
		mex -DPOLY2 libsvmwrite.c
		mex -DPOLY2 train.c linear_model_matlab.c ../linear.cpp ../tron.cpp ../blas/*.c
		mex -DPOLY2 predict.c linear_model_matlab.c ../linear.cpp ../tron.cpp ../blas/*.c
	% This part is for MATLAB
	% Add -largeArrayDims on 64-bit machines of MATLAB
	else
        mex CFLAGS="\$CFLAGS -std=c99" -largeArrayDims -DPOLY2 libsvmread.c
		mex CFLAGS="\$CFLAGS -std=c99" -largeArrayDims -DPOLY2 libsvmwrite.c
		mex CFLAGS="\$CFLAGS -std=c99" -largeArrayDims -DPOLY2 train.c linear_model_matlab.c ../linear.cpp ../tron.cpp "../blas/*.c"
		mex CFLAGS="\$CFLAGS -std=c99" -largeArrayDims -DPOLY2 predict.c linear_model_matlab.c ../linear.cpp ../tron.cpp "../blas/*.c"
	end
catch
	fprintf('If make.m failes, please check README about detailed instructions.\n');
end
