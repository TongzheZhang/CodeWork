#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <math.h>
#include "linear.h"
#include "block.h"
#define Malloc(type,n) (type *)malloc((n)*sizeof(type))
#define INF HUGE_VAL

void exit_with_help()
{
	printf(
	"Usage: blocktrain [options] training_set_file [model_file]\n"
	"options:\n"
	"-s type : set type of solver (default 1)\n"
	"	1 -- BLOCK L2-loss support vector machines (dual)\n"	
	"	3 -- BLOCK L1-loss support vector machines (dual)\n"
	"	4 -- multi-class support vector machines by Crammer and Singer\n"
	"	7 -- BLOCK L2-loss logistic regression (dual)\n"
	"-c cost : set the parameter C (default 1)\n"
	"-e epsilon : set tolerance of termination criterion\n"
	"	-s 1, 3, 4, and 7\n"
	"		Dual maximal violation <= eps; similar to liblinear (default 0.001)\n"
	"-E inner_epsilon : set the stopping tolerance for solving each sub-problem (default 0.05)\n"
	"-M inner_max_iter : set the maximal number of coordinate descent iterations in solving each sub-problem (default 200)\n"
	"-m max_iter : set the maximal number of outer iterations (default 5)\n"
	"-O cache_size : the amount of memory used for caching informative samples (MB) (default 1000)\n"
	"-B bias : if bias >= 0, instance x becomes [x; bias]; if < 0, no bias term added (default -1)\n"
	"-wi weight : weights adjust the parameter C of different classes (see README for details)\n"
	"-v n : n-fold cross validation mode\n"
	"-a warm_start_cookie : the file stores w and alpha for warm start\n"
	);
	exit(1);
}

void parse_command_line(int argc, char **argv, char *input_file_name, char *model_file_name);
void do_cross_validation();

struct parameter param;
block_problem bprob;
struct model* model_;
int flag_cross_validation;
int nr_fold;
double bias;

int main(int argc, char **argv)
{
	char input_file_name[1024];
	char model_file_name[1024];
	const char *error_msg;

	parse_command_line(argc, argv, input_file_name, model_file_name);
	bprob.read_metadata(input_file_name);
	bprob.prob_.allocate_buf(bprob.max_buflen + param.max_cache_memory*1000000);
	bprob.set_bias(bias);
	error_msg = block_check_parameter(&bprob,&param);

	if(error_msg)
	{
		fprintf(stderr,"Error: %s\n",error_msg);
		exit(1);
	}

	srand(1);
	if(flag_cross_validation)
		do_cross_validation();
	else
	{
		model_=block_train(&bprob, &param);
		save_model(model_file_name, model_);
		free_and_destroy_model(&model_);
	}
	destroy_param(&param);

	return 0;
}

void do_cross_validation()
{
	double cvrate = block_cross_validation(&bprob,&param,nr_fold);
	printf("Cross Validation Accuracy = %g%%\n",100.0*cvrate);
}


void parse_command_line(int argc, char **argv, char *input_file_name, char *model_file_name)
{
	int i;

	// default values
	param.solver_type = L2R_L2LOSS_SVC_DUAL;
	param.C = 1;
	param.eps = INF; // see setting below
	param.inner_eps = 0.05;
	param.max_iter = 5;
	param.inner_max_iter = 200;
	param.nr_weight = 0;
	param.weight_label = NULL;
	param.weight = NULL;
	param.warm_start_cookie = NULL;
	param.max_cache_memory = 1000;
	flag_cross_validation = 0;
	bias = -1;

	// parse options
	for(i=1;i<argc;i++)
	{
		if(argv[i][0] != '-') break;
		if(++i>=argc)
			exit_with_help();
		switch(argv[i-1][1])
		{
			case 's':
				param.solver_type = atoi(argv[i]);
				break;

			case 'c':
				param.C = atof(argv[i]);
				break;

			case 'e':
				param.eps = atof(argv[i]);
				break;

			case 'E':
				param.inner_eps = atof(argv[i]);
				break;

			case 'm':
				param.max_iter = atoi(argv[i]);
				break;

			case 'O':
				param.max_cache_memory = atoi(argv[i]);
				break;

			case 'M':
				param.inner_max_iter = atoi(argv[i]);
				break;

			case 'B':
				bias = atof(argv[i]);
				break;

			case 'w':
				++param.nr_weight;
				param.weight_label = (int *) realloc(param.weight_label,sizeof(int)*param.nr_weight);
				param.weight = (double *) realloc(param.weight,sizeof(double)*param.nr_weight);
				param.weight_label[param.nr_weight-1] = atoi(&argv[i-1][2]);
				param.weight[param.nr_weight-1] = atof(argv[i]);
				break;

			case 'v':
				flag_cross_validation = 1;
				nr_fold = atoi(argv[i]);
				if(nr_fold < 2)
				{
					fprintf(stderr,"n-fold cross validation: n must >= 2\n");
					exit_with_help();
				}
				break;

			case 'a':
				param.warm_start_cookie = argv[i];
				break;

			default:
				fprintf(stderr,"unknown option: -%c\n", argv[i-1][1]);
				exit_with_help();
				break;
		}
	}

	// determine filenames
	if(i>=argc)
		exit_with_help();

	strcpy(input_file_name, argv[i]);

	if(i<argc-1)
		strcpy(model_file_name,argv[i+1]);
	else
	{
		size_t len = strlen(argv[i]);
		if(argv[i][len-1] == '/') 
			argv[i][len-1] = 0;
		char *p = strrchr(argv[i],'/');
		if(p==NULL)
			p = argv[i];
		else
			++p;
		sprintf(model_file_name,"%s.model",p);
	}

	if(param.eps == INF)
	{
		if(param.solver_type == L2R_LR || param.solver_type == L2R_L2LOSS_SVC)
			param.eps = 0.01;
		else if(param.solver_type == L2R_L2LOSS_SVC_DUAL || param.solver_type == L2R_L1LOSS_SVC_DUAL || param.solver_type == MCSVM_CS || param.solver_type == L2R_LR_DUAL)
			param.eps = 0.001;
		else if(param.solver_type == L1R_L2LOSS_SVC || param.solver_type == L1R_LR)
			param.eps = 0.01;
	}
}


