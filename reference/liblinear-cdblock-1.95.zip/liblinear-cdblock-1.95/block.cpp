#include <math.h>
#include <time.h>
#include <algorithm>
#include <set>
#include <assert.h>
#include "zlib/zlib.h"
#include "block.h"

const char *data_format_table[] = {
	"BINARY", "COMPRESSION", NULL
};

#define Malloc(type,n) (type *)malloc((n)*sizeof(type))
#define Realloc(ptr, type, n) (type *)realloc((ptr), (n)*sizeof(type))
#define INF HUGE_VAL

using namespace std;

void myfread(void *ptr, size_t size, size_t nmemb, FILE * stream) 
{
	size_t ret = fread(ptr, size, nmemb, stream);
	if(ret != nmemb) 
	{
		fprintf(stderr, "Read Error! Bye Bye %ld %ld\n", ret, size*nmemb);
		exit(-1);
	}
}

struct index_cmp {
	index_cmp(const double* arr) : arr(arr) {}
	bool operator()(const size_t a, const size_t b) const
	{
		return arr[a] < arr[b]; }
	const double* arr;
};

#define CHUNKSIZE 1073741824UL
int myuncompress(void *dest, size_t *destlen, const void *source, size_t sourcelen)
{
	int ret;
	z_stream strm;

	strm.zalloc = Z_NULL;
	strm.zfree = Z_NULL;
	strm.opaque = Z_NULL;
	strm.avail_in = 0;
	strm.next_in = Z_NULL;
	ret = inflateInit(&strm);
	if (ret != Z_OK)
	{
		(void)inflateEnd(&strm);
		return ret;
	}

	unsigned char *in = (unsigned char *)source;
	unsigned char *out = (unsigned char *)dest;
	unsigned long bytesread = 0, byteswritten = 0;

	/* decompress until deflate stream ends or end of file */
	do {
		strm.avail_in = (uInt) min(CHUNKSIZE, sourcelen - bytesread);
		//finish all input
		if (strm.avail_in == 0)
			break;
		strm.next_in = in + bytesread;
		bytesread += strm.avail_in;

		/* run inflate() on input until output buffer not full */
		do {
			strm.avail_out = (uInt)CHUNKSIZE;
			strm.next_out = out + byteswritten;
			ret = inflate(&strm, Z_NO_FLUSH);
			assert(ret != Z_STREAM_ERROR);  /* state not clobbered */
			switch (ret)
			{
				case Z_NEED_DICT:
					ret = Z_DATA_ERROR;     /* and fall through */
				case Z_DATA_ERROR:
				case Z_MEM_ERROR:
					(void)inflateEnd(&strm);
					return ret;
			}
			byteswritten += CHUNKSIZE - strm.avail_out;
		} while (strm.avail_out == 0);

		/* done when inflate() says it's done */
	} while (ret != Z_STREAM_END);

	if(byteswritten != *destlen)
		fprintf(stderr,"Compressed file corrupted\n");
	*destlen = byteswritten;
	(void)inflateEnd(&strm);
	return 0;
}

// Body of class binaryfmt_problem
void binaryfmt_problem::set_bias(int idx, double val, int datafmt)
{
	if(bias >= 0) 
		fprintf(stderr, "Warning: the bias have been set to %lf\n.", bias);
	bias_idx = idx;
	bias = val;
}

void binaryfmt_problem::load_problem(const char* filename, int datafmt)
{
	FILE *fp = fopen(filename, "rb");
	load_header(fp);
	load_body(fp, datafmt);
	parse_binary();
	l = prob.l;
	n = prob.n;
	fclose(fp);
}

void binaryfmt_problem::allocate_buf(unsigned long buflen)
{
	buf = Malloc(unsigned char, buflen);
}

struct problem* binaryfmt_problem::get_problem()
{
	retprob = prob;
	if(bias >= 0 && prob.bias != bias)
	{
		struct feature_node node;
		prob.n = retprob.n = bias_idx;
		prob.bias = retprob.bias = bias;
		node.index = bias_idx;
		node.value = bias;

		for(int i=1;i<retprob.l;i++) 
			*(retprob.x[i]-2) = node; 
		x_space[n_x_space-2] = node;
	} 
	return &retprob;
}

void binaryfmt_problem::load_header(FILE *fp)
{
	myfread(&prob.l, sizeof(int), 1, fp);
	myfread(&prob.n, sizeof(int), 1, fp);
	myfread(&n_x_space, sizeof(unsigned long), 1, fp);
	myfread(&filelen, sizeof(unsigned long), 1, fp);
	prob.bias = -1;
	buflen = n_x_space * sizeof(struct feature_node) + prob.l * (sizeof(double)+sizeof(unsigned long));
}

void binaryfmt_problem::load_body(FILE *fp, int datafmt)
{
	if (buf == NULL)
		fprintf(stderr,"Memory Error!\n");
	if(datafmt == BINARY)
	{
		if (buflen != filelen)
		{
			fprintf(stderr,"l = %d n_x_space = %ld buflen%ld filelen = %ld\n",prob.l, n_x_space, buflen, filelen);
		}
		myfread(buf+cache_offset, sizeof(unsigned char), buflen, fp);
	} 
	else if(datafmt == COMPRESSION)
	{
		unsigned char *compressedbuf;
		compressedbuf = Malloc(unsigned char, filelen);
		myfread(compressedbuf, sizeof(unsigned char), filelen, fp);
		int retcode = myuncompress(buf+cache_offset, &buflen, compressedbuf, filelen);
		if(retcode != Z_OK)
		{
			fprintf(stderr, "OK %d MEM %d BUF %d DATA %d g %d %p %ld\n", Z_OK, Z_MEM_ERROR, 
					Z_BUF_ERROR, Z_DATA_ERROR, retcode, buf, buflen);
		}
		free(compressedbuf);
	}
}

void binaryfmt_problem::parse_binary()
{
	unsigned long offset = 0;
	x_space = (struct feature_node*) (buf + offset + cache_offset); 
	offset += sizeof(struct feature_node) * n_x_space;

	prob.y = (double*) (buf + offset + cache_offset); 
	offset += sizeof(double) * prob.l;

	prob.x = (struct feature_node**) (buf + offset + cache_offset);
	for(int i = 0; i < prob.l; i++) 
		prob.x[i] = x_space + (unsigned long)prob.x[i];	
	// to know the length of the last instance, we need to store the address of the end of x_space in prob.x[prob.l].
	// This address is the same as the start address of prob.y
	prob.x[prob.l] = (struct feature_node*) prob.y;
}

int binaryfmt_problem::move_cached_samples(struct problem *subprob, int *cache_index, unsigned long max_cache_memory) {
	unsigned long offset = 0;
	int cind = 0;

	// check how many samples can store in the memory cache
	for(cind=0; cind<subprob->l && offset<max_cache_memory*1000000; cind++)
	{
		int ind = cache_index[cind];
		unsigned long ins_size = sizeof(struct feature_node) * (subprob->x[ind+1] - subprob->x[ind]);
		offset += ins_size;
	}
	if(offset>max_cache_memory * 1000000)
		--cind;

	// store samples in the cache
	std::sort(cache_index, cache_index+cind);
	offset = 0;
	for(int i=0; i<cind; i++)
	{
		int ind = cache_index[i];
		unsigned long ins_size = sizeof(struct feature_node) * (subprob->x[ind+1] - subprob->x[ind]);
		memmove(buf+offset, subprob->x[ind], ins_size);
		subprob->x[ind] = (struct feature_node*) (buf+offset);
		offset += ins_size;
	}
	cache_offset = offset;
	return cind;
}

// Body of Class block_problem
void block_problem::set_bias(double b)
{
	bias = b;
	if(bias>=0) n+=1;
	prob_.set_bias(n, b, datafmt);
}

void block_problem::read_metadata(const char* dirname)
{
	char filename[1024], fmt[81];
	sprintf(filename,"%s/meta", dirname);
	FILE *meta = fopen(filename, "r");
	if(meta == NULL)
	{
		fprintf(stderr,"can't open input file %s\n",filename);
		exit(1);
	}
	fscanf(meta, "%s", fmt);
	for(int i = 0; data_format_table[i]; i++)
		if (strcmp(data_format_table[i], fmt) == 0) 
			datafmt = i;
	if(datafmt == -1)
	{
		fprintf(stderr, "Unsupported binary data format\n");
		exit(-1);
	}
	fscanf(meta, "%d %d %d %d", &nBlocks, &l, &n, &nr_class);
	label.resize(nr_class, 0);
	for(int i = 0; i < nr_class; i++)
		fscanf(meta, "%d", &label[i]);

	if (nr_class == 2 && label[0] == -1 && label[1] == 1)
		swap(label[0],label[1]);

	binary_files.resize(nBlocks,"");
	start.resize(nBlocks,0);
	subl.resize(nBlocks,0);
	unsigned long  buflen;
	max_buflen = 0;
	for(int i = 0; i < nBlocks; i++)
	{
		fscanf(meta, "%d %d %ld %s", &start[i], &subl[i], &buflen, filename);
		max_buflen = max(max_buflen, buflen);
		binary_files[i] = string(dirname) + "/" + string(filename); 
	}

	// To store prob.x[prob.l]
	max_buflen += sizeof(feature_node*);
	fclose(meta);
}

struct problem* block_problem::get_block(int id)
{
	if (id >= nBlocks)
	{
		fprintf(stderr,"Wrong Block Id %d; only %d blocks\n", id, nBlocks);
		exit(-1);
		return NULL;
	}
	prob_.load_problem(binary_files[id].c_str(), datafmt);
	return prob_.get_problem();
}

// Used only by CV at this moment
block_problem block_problem::gen_sub_problem(const vector<int>& blocklist)
{
	block_problem subbprob;
	subbprob.nBlocks = (int)blocklist.size();
	subbprob.n = n;
	subbprob.nr_class = nr_class;
	subbprob.bias = bias;
	subbprob.datafmt = datafmt;
	subbprob.label = label;

	subbprob.l = 0;
	for(int i = 0; i < subbprob.nBlocks; i++)
	{
		int bid = blocklist[i];
		subbprob.start.push_back(subbprob.l);
		subbprob.subl.push_back(subl[bid]);
		subbprob.binary_files.push_back(binary_files[bid]);
		subbprob.l += subl[bid];
	}

	return subbprob;
}

int block_problem::move_cached_samples(struct problem *subprob, int *cached_index, unsigned long max_cache_memory) {
	switch (datafmt) {
		case BINARY:
		case COMPRESSION:
			return prob_.move_cached_samples(subprob, cached_index, max_cache_memory);
			break;
		default:
			fprintf(stderr, "Unsupported data format\n");
			exit(-1);
			break;
	}
}

class cookie_handler
{
	public:
		void push_item(void *ptr, size_t size) 
		{
			ptr_vec.push_back(ptr);
			size_vec.push_back(size);
		}
		void dump(const char *filename)
		{
			FILE *fp = fopen(filename, "wb");
			if(fp == NULL)
			{
				fprintf(stderr,"can't open file %s\n",filename);
				exit(1);
			}
			for(size_t i = 0; i < ptr_vec.size(); i++)
				fwrite(ptr_vec[i], 1, size_vec[i], fp);
			fclose(fp);
		}
		void load(const char *filename)
		{
			FILE *fp = fopen(filename, "rb");
			if(fp == NULL) // default fill zero
				for(size_t i = 0; i < ptr_vec.size(); i++)
					memset(ptr_vec[i], 0, size_vec[i]);
			else
			{
				for(size_t i = 0; i < ptr_vec.size(); i++)
					fread(ptr_vec[i], 1, size_vec[i], fp);
				fclose(fp);
			}
		}
	private:
		vector<void*> ptr_vec;
		vector<size_t> size_vec;
};

void block_solve_l2r_l1l2_svc(block_problem *bprob, const parameter *param, double *w, double Cp, double Cn)
{
	int nBlocks = bprob->nBlocks;
	int l = bprob->l;
	int n = bprob->n;
	int solver_type = param->solver_type;
	int max_iter=param->max_iter;
	int inner_max_iter=param->inner_max_iter;
	double eps=param->eps;
	double inner_eps = param->inner_eps;
	double PGmax=-INF, PGmin=INF;
	if(solver_type != L2R_L2LOSS_SVC_DUAL && solver_type != L2R_L1LOSS_SVC_DUAL)
	{
		fprintf(stderr, "Error: unknown solver_type or unsupported solver_type\n");
		return;
	}

	double *y = new double[l];
	double *alpha = new double[l];
	int iter = 0;
	bool label_unloaded = true;
	int *perm = new int[nBlocks];
	for(int i = 0; i < nBlocks; i++)
		perm[i] = i;

	time_t start_t, startload_t;
	double total_time=0, total_load=0;

	struct problem subprob;
	struct problem cached_samples;
	subprob.x = cached_samples.x = NULL;
	subprob.y = cached_samples.y = NULL;
	cached_samples.l = 0;
	cached_samples.n = subprob.n = n;
	cached_samples.bias = subprob.bias = bprob->bias;

	int *index = NULL;
	int *cache_index=NULL;
	double *sub_alpha = NULL, *cached_score=NULL;

	// Initial cookie handler
	cookie_handler cookie;
	cookie.push_item(w, sizeof(double)*n);
	cookie.push_item(alpha, sizeof(double)*l);
	cookie.push_item(&total_time, sizeof(double));
	cookie.push_item(&total_load, sizeof(double));
	cookie.push_item(&iter, sizeof(int));
	cookie.load(param->warm_start_cookie);
	max_iter += iter;

	while (iter < max_iter)
	{
		start_t = time(NULL);
		PGmax = -INF;
		PGmin = INF;
		iter++;

		for (int i=0; i<nBlocks; i++)
		{
			int j = i+rand()%(nBlocks-i);
			swap(perm[i], perm[j]);
		}

		for (int i=0; i < nBlocks; i++)
		{
			startload_t = time(NULL);
			struct problem *block_data;
			total_load += difftime(time(NULL), startload_t);
			int start = bprob->start[perm[i]];

			// select cached samples depend on
			// the results of last subprob (last block + cache)
			if(subprob.x != NULL)
			{
				// to avoid duplicating training samples, do not put the samples
				// of next block into cache
				int end = start + bprob->subl[perm[i]];
				int samples_in_block = 0;
				for(int j=0; j<subprob.l; j++)
				{
					cache_index[j] = j;
					if(index[j] >= start && index[j] < end)
					{
						cached_score[j] = INF;
						samples_in_block++;
					}
				}
				for(int j=0; j<subprob.l; j++)
				{
					int k = j+rand() % (subprob.l-j);
					swap(cache_index[j], cache_index[k]);
				}
				std::sort(cache_index, cache_index+subprob.l, index_cmp(cached_score));
				subprob.l -= samples_in_block;

				cached_samples.l = bprob->move_cached_samples(&subprob, cache_index, param->max_cache_memory);
				cached_samples.x = Realloc(cached_samples.x, feature_node*, cached_samples.l);
				cached_samples.y = Realloc(cached_samples.y, double, cached_samples.l);
				for(int j=0; j<cached_samples.l; j++)
				{
					index[j] = index[cache_index[j]];
					cached_samples.x[j] = subprob.x[cache_index[j]];
					cached_samples.y[j] = subprob.y[cache_index[j]];
				}			
			}
			
			block_data = bprob->get_block(perm[i]);

			if(label_unloaded)
			{
				for(int j = start; j < start + block_data->l; j++)
				{
					int lb = block_data->y[j-start];
					if(lb == bprob->label[0]) y[j] = 1;
					else if (lb == bprob->label[1]) y[j] = -1;
					else 
					{
						printf("id=%d, start = %d, l = %d datafmt = %d\n", i, start, block_data->l, bprob->datafmt);
						fprintf(stderr,"The label is wrong %d %d %d\n", lb, bprob->label[0], bprob->label[1]);
						exit(-1);
					}
				}
			}

			block_data->y = y+start;

			// sub-problem consisting of two parts: (1) cached samples (2) new data loaded from disk
			subprob.x = Realloc(subprob.x, feature_node*, cached_samples.l + block_data->l + 1);
			subprob.y = Realloc(subprob.y, double, cached_samples.l + block_data->l);
			sub_alpha = Realloc(sub_alpha, double, cached_samples.l + block_data->l);
			index = Realloc(index, int, cached_samples.l + block_data->l);

			// (1) cached samples
			int ind=0;
			for(int j=0; j<cached_samples.l; j++)
			{
				subprob.x[ind] = cached_samples.x[j];
				subprob.y[ind] = cached_samples.y[j];
				sub_alpha[ind] = alpha[index[j]];
				index[ind] = index[j];
				ind++;
			}
			int offset = ind;

			// (2) new data block from disk
			for(int j=0; j<block_data->l; j++)
			{
				subprob.x[offset+j] = block_data->x[j];
				subprob.y[offset+j] = block_data->y[j];
				sub_alpha[offset+j] = alpha[start + j];
				index[offset+j] = start + j;
			}
			subprob.x[offset+block_data->l] = block_data->x[block_data->l];
			subprob.l = offset + block_data->l;

			cached_score = Realloc(cached_score, double, subprob.l);
			cache_index = Realloc(cache_index, int, subprob.l);

			double PGmax_ , PGmin_ ;
			solve_l2r_l1l2_svc(&subprob,
					w, sub_alpha, inner_eps, Cp, Cn, solver_type,
					&PGmax_, &PGmin_, cached_score, inner_max_iter);

			for(int j=0; j<subprob.l; j++)
				alpha[index[j]] = sub_alpha[j];

			PGmax = max(PGmax, PGmax_);
			PGmin = min(PGmin, PGmin_);
		}
		label_unloaded = false; // labels are loaded at the first iteration

		total_time += difftime(time(NULL), start_t);
		double v = 0;
		// calculate dual obj
		double diag_p = 0.5/Cp, diag_n = 0.5/Cn;
		if(solver_type == L2R_L1LOSS_SVC_DUAL)
			diag_p = diag_n = 0;

		int nSV = 0;
		for(int i=0; i<n; i++)
			v += w[i]*w[i];
		for(int i=0; i<l; i++)
		{
			if (y[i] == 1)
				v += alpha[i]*(alpha[i]*diag_p - 2); 
			else
				v += alpha[i]*(alpha[i]*diag_n - 2);
			if(alpha[i] > 0)
				++nSV;
		}

		printf("iter %d time %.5g runtime %.5g loadtime %.5g obj %g PGmax %.5g PGmin %.5g gap %.5g\n", 
				iter, total_time, total_time-total_load, total_load,  v/2,  PGmax, PGmin, PGmax - PGmin);
		fflush(stdout);
		if(PGmax - PGmin < eps)
			break;

	}

	if(param->warm_start_cookie)
		cookie.dump(param->warm_start_cookie);

	delete [] y;
	delete [] perm;
	delete [] alpha;
	free(index);
	free(sub_alpha);
	free(cached_score);
	free(cache_index);
	free(cached_samples.x);
	free(cached_samples.y);
	free(subprob.x);
	free(subprob.y);
}

void block_solve_l2r_lr_dual(block_problem *bprob, const parameter *param, double *w, double Cp, double Cn)
{
	int nBlocks = bprob->nBlocks;
	int l = bprob->l;
	int n = bprob->n;
	int solver_type = param->solver_type;
	int max_iter = param->max_iter;
	int inner_max_iter=param->inner_max_iter;
	double eps = param->eps;
	double inner_eps = param->inner_eps;
	double Gmax;
	if(solver_type != L2R_LR_DUAL)
	{
		fprintf(stderr, "Error: unknown solver_type or unsupported solver_type\n");
		return;
	}
	
	double *y = new double[l];
	double *alpha = new double[2*l];
	int iter = 0;
	bool label_unloaded = true;
	int *perm = new int[nBlocks];
	for(int i = 0; i < nBlocks; i++)
		perm[i] = i;

	time_t start_t, startload_t;
	double total_time=0, total_load=0;

	struct problem subprob;
	struct problem cached_samples;
	subprob.x = cached_samples.x = NULL;
	subprob.y = cached_samples.y = NULL;
	cached_samples.l = 0;
	cached_samples.n = subprob.n = n;
	cached_samples.bias = subprob.bias = bprob->bias;

	int *index = NULL;
	int *cache_index=NULL;
	double *sub_alpha = NULL, *cached_score=NULL;

	// Initial cookie handler
	cookie_handler cookie;
	cookie.push_item(w, sizeof(double)*n);
	cookie.push_item(alpha, sizeof(double)*2*l);
	cookie.push_item(&total_time, sizeof(double));
	cookie.push_item(&total_load, sizeof(double));
	cookie.push_item(&iter, sizeof(int));
	cookie.load(param->warm_start_cookie);
	max_iter += iter;

	while (iter < max_iter)
	{
		start_t = time(NULL);
		Gmax = 0;
		iter++;
		for (int i=0; i<nBlocks; i++)
		{
			int j = i+rand()%(nBlocks-i);
			swap(perm[i], perm[j]);
		}
				
		for (int i=0; i < nBlocks; i++)
		{
			startload_t = time(NULL);
			struct problem *block_data;
			total_load += difftime(time(NULL), startload_t);
			int start = bprob->start[perm[i]];

			// select cached samples depend on
			// the results of last subprob (last block + cache)
			if(subprob.x != NULL)
			{
				// to avoid duplicating training samples, do not put the samples
				// of next block into cache
				int end = start + bprob->subl[perm[i]];
				int samples_in_block = 0;
				for(int j=0; j<subprob.l; j++)
				{
					cache_index[j] = j;
					if(index[j] >= start && index[j] < end)
					{
						cached_score[j] = INF;
						samples_in_block++;
					}
				}
				for(int j=0; j<subprob.l; j++)
				{
					int k = j+rand() % (subprob.l-j);
					swap(cache_index[j], cache_index[k]);
				}
				std::sort(cache_index, cache_index+subprob.l, index_cmp(cached_score));
				subprob.l -= samples_in_block;

				cached_samples.l = bprob->move_cached_samples(&subprob, cache_index, param->max_cache_memory);
				cached_samples.x = Realloc(cached_samples.x, feature_node*, cached_samples.l);
				cached_samples.y = Realloc(cached_samples.y, double, cached_samples.l);
				for(int j=0; j<cached_samples.l; j++)
				{
					index[j] = index[cache_index[j]];
					cached_samples.x[j] = subprob.x[cache_index[j]];
					cached_samples.y[j] = subprob.y[cache_index[j]];
				}			
			}
			
			block_data = bprob->get_block(perm[i]);

			if(label_unloaded)
			{
				for(int j = start; j < start + block_data->l; j++)
				{
					int lb = block_data->y[j-start];
					if(lb == bprob->label[0]) y[j] = 1;
					else if (lb == bprob->label[1]) y[j] = -1;
					else 
					{
						printf("id=%d, start = %d, l = %d datafmt = %d\n", i, start, block_data->l, bprob->datafmt);
						fprintf(stderr,"The label is wrong %d %d %d\n", lb, bprob->label[0], bprob->label[1]);
						exit(-1);
					}
				}
			}
			
			if(iter == 1)	//we need to initial alpha and w
			{
				for(int j = start; j < start + block_data->l; j++)
				{
					if (y[j] == 1)
					{
						alpha[2*j] = min(0.001*Cp, 1e-8);
						alpha[2*j+1] = Cp - alpha[2*j];
					}
					else
					{
						alpha[2*j] = min(0.001*Cn, 1e-8);
						alpha[2*j+1] = Cn - alpha[2*j];
					}	
					feature_node *xi = block_data->x[j-start];
                			while (xi->index != -1)
                			{
                        			w[xi->index-1] += y[j]*alpha[2*j]*xi->value;
                        			xi++;
                			}
				}
			}
			
			block_data->y = y+start;
		
			// sub-problem consisting of two parts: (1) cached samples (2) new data loaded from disk			
			subprob.x = Realloc(subprob.x, feature_node*, cached_samples.l + block_data->l + 1);
			subprob.y = Realloc(subprob.y, double, cached_samples.l + block_data->l);
			sub_alpha = Realloc(sub_alpha, double, (cached_samples.l + block_data->l)*2);
			index = Realloc(index, int, cached_samples.l + block_data->l);
			// (1) cached samples
			int ind=0;
			for(int j=0; j<cached_samples.l; j++)
			{
				subprob.x[ind] = cached_samples.x[j];
				subprob.y[ind] = cached_samples.y[j];
				sub_alpha[2*ind] = alpha[2*index[j]];
				sub_alpha[2*ind+1] = alpha[2*index[j]+1];
				index[ind] = index[j];
				ind++;
			}
			int offset = ind;

			// (2) new data block from disk
			for(int j=0; j<block_data->l; j++)
			{
				subprob.x[offset+j] = block_data->x[j];
				subprob.y[offset+j] = block_data->y[j];
				sub_alpha[2*(offset+j)] = alpha[2*(start + j)];
				sub_alpha[2*(offset+j)+1] = alpha[2*(start + j)+1];
				index[offset+j] = start + j;
			}
			subprob.x[offset+block_data->l] = block_data->x[block_data->l];
			subprob.l = offset + block_data->l;

			cached_score = Realloc(cached_score, double, subprob.l);
			cache_index = Realloc(cache_index, int, subprob.l);

			double Gmax_;
			solve_l2r_lr_dual(&subprob,
					w, sub_alpha, inner_eps, Cp, Cn, &Gmax_, cached_score, inner_max_iter);

			for(int j=0; j<subprob.l; j++)
			{
				alpha[2*index[j]] = sub_alpha[2*j];
				alpha[2*index[j]+1] = sub_alpha[2*j+1];
			}

			Gmax = max(Gmax, Gmax_);
		}
		label_unloaded = false; // labels are loaded at the first iteration

		total_time += difftime(time(NULL), start_t);
		double v = 0;
		// calculate dual obj
		for(int i=0; i<n; i++)
			v += w[i]*w[i];
		v *= 0.5;
		for(int i=0; i<l; i++)
		{
			if(y[i] > 0)
				v += alpha[2*i] * log(alpha[2*i]) + alpha[2*i+1] * log(alpha[2*i+1])
					- Cp * log(Cp);
			else
				v += alpha[2*i] * log(alpha[2*i]) + alpha[2*i+1] * log(alpha[2*i+1]) 
					- Cn * log(Cn);
		}

		printf("iter %d time %.5g runtime %.5g loadtime %.5g obj %lf\n", 
				iter, total_time, total_time-total_load, total_load, v);
		fflush(stdout);
		if(Gmax < eps)
			break;

	}

	if(param->warm_start_cookie)
		cookie.dump(param->warm_start_cookie);

	delete [] y;
	delete [] perm;
	delete [] alpha;
	free(index);
	free(sub_alpha);
	free(cached_score);
	free(cache_index);
	free(cached_samples.x);
	free(cached_samples.y);
	free(subprob.x);
	free(subprob.y);
}

void block_train_MCSVM_CS(block_problem *bprob, const parameter *param, double *w, int nr_class, double *weighted_C)
{
	int nBlocks = bprob->nBlocks;
	int l = bprob->l;
	int n = bprob->n;
	vector<int> &label = bprob->label;

	int solver_type = param->solver_type;
	int max_iter = param->max_iter;
	int inner_max_iter = param->inner_max_iter;
	double eps=param->eps;
	double inner_eps = param->inner_eps;
	double stopping = -INF;
	if(solver_type != MCSVM_CS)
	{
		fprintf(stderr, "Error: unknown solver_type or unsupported solver_type\n");
		return;
	}
	double *y = new double[l];
	double *alpha = new double[l*nr_class];
	int iter = 0;
	bool label_unloaded = true;
	int *perm = new int[nBlocks];
	for(int i = 0; i < nBlocks; i++)
		perm[i] = i;
	time_t start_t, startload_t;
	double total_time=0, total_load=0;

	struct problem subprob;
	struct problem cached_samples;
	subprob.x = cached_samples.x = NULL;
	subprob.y = cached_samples.y = NULL;
	cached_samples.l = 0;
	cached_samples.n = subprob.n = n;
	cached_samples.bias = subprob.bias = bprob->bias;

	int *index = NULL;
	int *cache_index = NULL;
	double *sub_alpha = NULL, *cached_score=NULL;

	// Initial cookie handler
	cookie_handler cookie;
	cookie.push_item(w, sizeof(double)*n*nr_class);
	cookie.push_item(alpha, sizeof(double)*l*nr_class);
	cookie.push_item(&total_time, sizeof(double));
	cookie.push_item(&total_load, sizeof(double));
	cookie.push_item(&iter, sizeof(int));
	cookie.load(param->warm_start_cookie);
	max_iter += iter;

	while (iter < max_iter)
	{
		start_t = time(NULL);
		stopping = -INF;
		iter++;
		
		for (int i=0; i<nBlocks; i++)
		{
			int j = i+rand()%(nBlocks-i);
			swap(perm[i], perm[j]);
		}

		for (int i=0; i < nBlocks; i++)
		{
			startload_t = time(NULL);
			struct problem *block_data;
			total_load += difftime(time(NULL), startload_t);
			int start = bprob->start[perm[i]];
		
			// select cached samples depend on
			// the results of last subprob (last block + cache)
			if(subprob.x != NULL)
			{
				// to avoid duplicating training samples, do not put the samples
				// of next block into cache
				int end = start + bprob->subl[perm[i]];
				int samples_in_block = 0;
				for(int j=0; j<subprob.l; j++)
				{
					cache_index[j] = j;
					if(index[j] >= start && index[j] < end)
					{
						cached_score[j] = INF;
						samples_in_block++;
					}
				}
				for(int j=0; j<subprob.l; j++)
				{
					int k = j+rand() % (subprob.l-j);
					swap(cache_index[j], cache_index[k]);
				}
				std::sort(cache_index, cache_index+subprob.l, index_cmp(cached_score));
				subprob.l -= samples_in_block;

				cached_samples.l = bprob->move_cached_samples(&subprob, cache_index, param->max_cache_memory);
				cached_samples.x = Realloc(cached_samples.x, feature_node*, cached_samples.l);
				cached_samples.y = Realloc(cached_samples.y, double, cached_samples.l);
				for(int j=0; j<cached_samples.l; j++)
				{
					index[j] = index[cache_index[j]];
					cached_samples.x[j] = subprob.x[cache_index[j]];
					cached_samples.y[j] = subprob.y[cache_index[j]];
				}		
			}

			block_data = bprob->get_block(perm[i]);
			
			if(label_unloaded)
			{
				for(int j = start; j < start + block_data->l; j++)
				{
					int lb =  block_data->y[j - start], k;
					for(k = 0; k < nr_class; k++)
						if(lb == label[k])
						{
							y[j] = k;
							break;
						}
					if(k == nr_class)
					{
						fprintf(stderr,"Wrong label\n");
						exit(-1);
					}
				}
			}

			block_data->y = y + start;
			double stopping_;

			// sub-problem consisting of two parts: (1) cached samples (2) new data loaded from disk			
			subprob.x = Realloc(subprob.x, feature_node*, cached_samples.l + block_data->l + 1);
			subprob.y = Realloc(subprob.y, double, cached_samples.l + block_data->l);
			sub_alpha = Realloc(sub_alpha, double, (cached_samples.l + block_data->l)*nr_class);
			index = Realloc(index, int, cached_samples.l + block_data->l);

			// (1) cached samples
			int ind=0;
			for (int j=0; j<cached_samples.l; j++)
			{
				subprob.x[ind] = cached_samples.x[j];
				subprob.y[ind] = cached_samples.y[j];
				for (int k=0; k<nr_class; k++)
					sub_alpha[ind*nr_class + k] = alpha[index[j]*nr_class + k];
				index[ind] = index[j];
				ind++;
			}
			int offset = ind;

			// (2) new data block from disk
			for(int j=0; j<block_data->l; j++)
			{
				subprob.x[offset+j] = block_data->x[j];
				subprob.y[offset+j] = block_data->y[j];
				for (int k=0; k<nr_class; k++)
					sub_alpha[(offset+j)*nr_class + k] = alpha[(start + j)*nr_class + k];
				index[offset+j] = start + j;
			}
			subprob.x[offset+block_data->l] = block_data->x[block_data->l];
			subprob.l = offset + block_data->l;

			cached_score = Realloc(cached_score, double, subprob.l);
			cache_index = Realloc(cache_index, int, subprob.l);


			Solver_MCSVM_CS Solver(&subprob, nr_class, weighted_C, inner_eps, inner_max_iter);
			Solver.Solve(w, sub_alpha, &stopping_, cached_score);
			stopping = max(stopping, stopping_);

			for(int j=0; j<subprob.l; j++)
				for(int k=0; k<nr_class; k++)
					alpha[index[j]*nr_class + k] = sub_alpha[j*nr_class + k];
		
		}
		label_unloaded = false; // all label are loaded when go through all block one time

		total_time += difftime(time(NULL), start_t);

		// calculate object value
		double v = 0;
		int nSV = 0;
		for(int i=0;i<n*nr_class;i++)
			v += w[i]*w[i];
		v = 0.5*v;
		for(int i=0;i<l*nr_class;i++)
		{
			v += alpha[i];
			if(fabs(alpha[i]) > 0)
				nSV++;
		}
		for(int i=0;i<l;i++)
			v -= alpha[(int)(i*nr_class+y[i])];

		printf("iter %d time %.5g runtime %.5g loadtime %.5g obj %g stopping %.5g\n", 
				iter, total_time, total_time-total_load, total_load, v, stopping);
		fflush(stdout);

		if(stopping < eps)
			break;
	}

	if(param->warm_start_cookie)
		cookie.dump(param->warm_start_cookie);

	delete [] y;
	delete [] perm;
	delete [] alpha;
	free(index);
	free(sub_alpha);
	free(cached_score);
	free(cache_index);
	free(cached_samples.x);
	free(cached_samples.y);
	free(subprob.x);
	free(subprob.y);
}

void block_train_one(block_problem *bprob, const parameter *param, double *w, double Cp, double Cn)
{
	switch (param->solver_type)
	{
		case L2R_L1LOSS_SVC_DUAL:
			block_solve_l2r_l1l2_svc(bprob, param, w, Cp, Cn);
			break;
		case L2R_L2LOSS_SVC_DUAL: 
			block_solve_l2r_l1l2_svc(bprob, param, w, Cp, Cn);
			break;
		case L2R_LR_DUAL: 
			block_solve_l2r_lr_dual(bprob, param, w, Cp, Cn);
			break;
		default:
			fprintf(stderr,"Not support for block version!\n");
	}
}

struct model* block_train(block_problem* bprob, const  parameter* param)
{
	//int l = bprob->l;
	int n = bprob->n;
	model *model_ = Malloc(model,1);

	if(bprob->bias>=0)
		model_->nr_feature=n-1;
	else
		model_->nr_feature=n;
	model_->param = *param;
	model_->bias = bprob->bias;

	int nr_class = bprob->nr_class;
	vector<int> &label = bprob->label;

	model_->nr_class = nr_class;
	model_->label = Malloc(int, nr_class);
	for(int i=0;i<nr_class;i++)
		model_->label[i] = label[i];

	// calculate weighted C
	double *weighted_C = Malloc(double, nr_class);

	for(int i=0;i<nr_class;i++)
		weighted_C[i] = param->C;
	for(int i=0;i<param->nr_weight;i++)
	{
		int j;
		for(j=0;j<nr_class;j++)
			if(param->weight_label[i] == label[j])
				break;
		if(j == nr_class)
			fprintf(stderr,"warning: class label %d specified in weight is not found\n", param->weight_label[i]);
		else
			weighted_C[j] *= param->weight[i];
	}


	if(param->solver_type == MCSVM_CS)
	{
		model_->w=Malloc(double, n*nr_class);
		block_train_MCSVM_CS(bprob, param, model_->w, nr_class, weighted_C);
	} 
	else 
	{
		if(nr_class == 2)
		{
			model_->w=Malloc(double, n);
			block_train_one(bprob, param, model_->w, weighted_C[0], weighted_C[1]);
		} 
		else 
		{
			fprintf(stderr, "Use -s 4 for Multiclass-SVM\n");
			exit(-1);
		}
	}

	free(weighted_C);
	return model_;
}

double block_testing(struct model *model_, block_problem *bprob)
{
	int correct = 0;
	for(int i=0; i<bprob->nBlocks; i++)
	{
		struct problem *subprob = bprob->get_block(i);
		for(int j=0;j<subprob->l;j++)
			if (predict(model_, subprob->x[j]) == subprob->y[j])
				correct++;
	}
	return (double)correct;
}

double block_cross_validation(block_problem *bprob, const parameter *param, int nr_fold)
{
	int *fold_start = Malloc(int,nr_fold+1);
	int nBlocks = bprob->nBlocks;
	int *perm = Malloc(int,nBlocks);
	double correct = 0.0;

	for(int i=0;i<nBlocks;i++) perm[i]=i;
	for(int i=0;i<nBlocks;i++)
	{
		int j = i+rand()%(nBlocks-i);
		swap(perm[i],perm[j]);
	}

	for(int i=0;i<=nr_fold;i++)
		fold_start[i]=i*nBlocks/nr_fold;

	for(int i=0;i<nr_fold;i++)
	{
		vector<int>subblock,valblock;
		int begin = fold_start[i];
		int end = fold_start[i+1];

		for(int j=0;j<begin;j++)
			subblock.push_back(perm[j]);
		for(int j=begin;j<end; j++)
			valblock.push_back(perm[j]);
		for(int j=end;j<nBlocks;j++)
			subblock.push_back(perm[j]);

		block_problem subprob = bprob->gen_sub_problem(subblock);
		block_problem valprob = bprob->gen_sub_problem(valblock);
		subprob.prob_.allocate_buf(bprob->max_buflen + param->max_cache_memory*1000000);
		valprob.prob_.allocate_buf(bprob->max_buflen*valblock.size() );

		struct model *submodel = block_train(&subprob, param);
		correct += block_testing(submodel, &valprob);
		free_and_destroy_model(&submodel);
	}
	free(fold_start);
	free(perm);

	return correct / bprob->l;
}

const char *block_check_parameter(const block_problem *bprob, const parameter *param)
{
	const char *error_msg = check_parameter(NULL,param);
	if(error_msg)
		return error_msg;
	if(param->solver_type != L2R_L2LOSS_SVC_DUAL
			&& param->solver_type != L2R_L1LOSS_SVC_DUAL
			&& param->solver_type != MCSVM_CS
			&& param->solver_type != L2R_LR_DUAL)
		return "Un-supported solver";
	return NULL;
}
